package com.soundpad.mobile

import android.app.Activity
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface

class MainActivity : Activity() {
    private data class Track(val uri: Uri, val name: String)
    private val sounds = mutableListOf<Track>()
    private var music: MediaPlayer? = null
    private val soundPlayers = mutableListOf<MediaPlayer>()
    private lateinit var root: LinearLayout
    private lateinit var soundList: LinearLayout
    private lateinit var musicStatus: TextView

    private val purple = Color.rgb(139, 92, 246)
    private val bg = Color.rgb(17, 19, 27)
    private val panel = Color.rgb(37, 41, 54)
    private val white = Color.WHITE
    private val muted = Color.rgb(170, 174, 190)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 28, 20, 24)
            setBackgroundColor(bg)
        }
        scroll.addView(root)
        setContentView(scroll)

        val title = TextView(this).apply {
            text = "SOUNDPAD"
            textSize = 28f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(title)
        val subtitle = TextView(this).apply {
            text = "Звуки и музыка в одном приложении"
            textSize = 14f
            setTextColor(muted)
            setPadding(0, 4, 0, 22)
        }
        root.addView(subtitle)

        section("SOUNDPAD — ЗВУКИ")
        rowButton("＋ Добавить звуки") { pickAudio(REQUEST_SOUNDS) }
        soundList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(soundList)
        refreshSounds()

        section("MUSIC — ПЛЕЕР")
        musicStatus = TextView(this).apply {
            text = "Музыка не выбрана"
            textSize = 14f
            setTextColor(muted)
            setPadding(0, 4, 0, 10)
        }
        root.addView(musicStatus)
        rowButton("＋ Выбрать музыку") { pickAudio(REQUEST_MUSIC) }
        rowButton("▶ Воспроизвести / продолжить") { playMusic() }
        rowButton("Ⅱ Пауза") { music?.pause(); updateMusicStatus("Пауза") }
        rowButton("■ Остановить") { stopMusic() }

        val note = TextView(this).apply {
            text = "\nПодсказка: добавь свои MP3, WAV или другие аудиофайлы через системный выбор файлов. Для одновременного звучания запускай несколько кнопок в разделе звуков."
            textSize = 12f
            setTextColor(muted)
        }
        root.addView(note)
    }

    private fun section(text: String) {
        val tv = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, 18, 0, 10)
        }
        root.addView(tv)
    }

    private fun rowButton(text: String, action: () -> Unit) {
        val b = Button(this).apply {
            this.text = text
            isAllCaps = false
            textSize = 14f
            setTextColor(white)
            setBackgroundColor(panel)
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 54)
        lp.bottomMargin = 9
        root.addView(b, lp)
    }

    private fun pickAudio(request: Int) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "audio/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, request == REQUEST_SOUNDS)
        }
        startActivityForResult(intent, request)
    }

    @Deprecated("Deprecated in Android API but supported for this starter")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        data.clipData?.let { clip ->
            for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        }
        data.data?.let { if (uris.isEmpty()) uris.add(it) }
        if (requestCode == REQUEST_SOUNDS) {
            uris.forEach { uri ->
                try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
                sounds.add(Track(uri, displayName(uri)))
            }
            refreshSounds()
        } else if (requestCode == REQUEST_MUSIC) {
            val uri = uris.firstOrNull() ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            try {
                music?.release()
                music = MediaPlayer().apply {
                    setDataSource(this@MainActivity, uri)
                    setOnCompletionListener { updateMusicStatus("Трек завершён") }
                    prepare()
                }
                updateMusicStatus(displayName(uri))
            } catch (e: Exception) {
                updateMusicStatus("Не удалось открыть этот аудиофайл")
            }
        }
    }

    private fun displayName(uri: Uri): String {
        val name = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':')
        return name?.takeIf { it.isNotBlank() } ?: "Аудиофайл"
    }

    private fun refreshSounds() {
        if (!::soundList.isInitialized) return
        soundList.removeAllViews()
        if (sounds.isEmpty()) {
            val empty = TextView(this).apply {
                text = "Пока нет звуков. Нажми «Добавить звуки»."
                setTextColor(muted)
                textSize = 13f
                setPadding(0, 6, 0, 12)
            }
            soundList.addView(empty)
        }
        sounds.forEachIndexed { index, track ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(10, 4, 4, 4)
                setBackgroundColor(panel)
            }
            val label = TextView(this).apply {
                text = track.name
                setTextColor(white)
                textSize = 13f
                maxLines = 2
            }
            item.addView(label, LinearLayout.LayoutParams(0, 54, 1f))
            val play = Button(this).apply {
                text = "▶"
                isAllCaps = false
                setTextColor(white)
                setBackgroundColor(purple)
                setOnClickListener { playSound(track.uri) }
            }
            item.addView(play, LinearLayout.LayoutParams(58, 48))
            val remove = Button(this).apply {
                text = "×"
                isAllCaps = false
                setTextColor(white)
                setBackgroundColor(panel)
                setOnClickListener { sounds.removeAt(index); refreshSounds() }
            }
            item.addView(remove, LinearLayout.LayoutParams(48, 48))
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.bottomMargin = 7
            soundList.addView(item, lp)
        }
    }

    private fun playSound(uri: Uri) {
        try {
            val player = MediaPlayer()
            player.setDataSource(this, uri)
            player.setOnCompletionListener {
                it.release()
                soundPlayers.remove(it)
            }
            player.setOnErrorListener { mp, _, _ ->
                mp.release()
                soundPlayers.remove(mp)
                true
            }
            player.prepare()
            player.start()
            soundPlayers.add(player)
        } catch (_: Exception) {
            // Unsupported or unavailable audio source; keep app running.
        }
    }

    private fun playMusic() {
        try {
            val p = music ?: run { updateMusicStatus("Сначала выбери музыкальный файл"); return }
            if (!p.isPlaying) p.start()
            updateMusicStatus("Воспроизведение")
        } catch (_: Exception) {
            updateMusicStatus("Не удалось запустить музыку")
        }
    }

    private fun stopMusic() {
        try {
            music?.pause()
            music?.seekTo(0)
            updateMusicStatus("Остановлено")
        } catch (_: Exception) {}
    }

    private fun updateMusicStatus(text: String) {
        if (::musicStatus.isInitialized) musicStatus.text = text
    }

    override fun onDestroy() {
        music?.release()
        soundPlayers.toList().forEach { try { it.release() } catch (_: Exception) {} }
        soundPlayers.clear()
        super.onDestroy()
    }

    companion object {
        private const val REQUEST_SOUNDS = 101
        private const val REQUEST_MUSIC = 102
    }
}
