# SOUNDPAD — Android Studio project

Starter Android app for a soundboard + local music player.

## Included
- Import multiple audio files as sound buttons
- Play sound effects independently (overlapping playback supported)
- Select one music file and play/pause/stop it
- Dark UI

## Build
1. Install Android Studio.
2. Open this folder (`SOUNDPAD`) in Android Studio.
3. Allow Gradle sync/downloads.
4. Connect an Android device with USB debugging enabled, or create an emulator.
5. Press Run.

Android Studio / Gradle plugin versions may prompt for an update depending on the installed environment.

## Current limitations
- This is source code for an Android Studio project, not a prebuilt APK.
- No background playback notification, playlists, equalizer, waveform, or audio routing into games/Discord yet.
- Audio sent directly into another app's microphone is restricted by Android and device firmware; ordinary playback through speaker/headphones works.
